import { AutomationSummary, User } from "./types";

export const currentUser: User = {
  id: "1",
  name: "Alex Morgan",
  email: "alex@wrk.com",
  avatar:
    "https://images.unsplash.com/photo-1672685667592-0392f458f46f?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwxfHxwcm9mZXNzaW9uYWwlMjBoZWFkc2hvdCUyMHBvcnRyYWl0fGVufDF8fHx8MTc2NDI5MDY1M3ww&ixlib=rb-4.1.0&q=80&w=1080",
};

export const mockAutomations: AutomationSummary[] = [
  {
    id: "1",
    name: "Invoice Processing",
    description: "Extracts data from PDF invoices and syncs to Xero.",
    department: "Finance",
    owner: currentUser,
    version: "v2.4",
    status: "Live",
    runs: 1240,
    success: 98.5,
    spend: 450,
    updated: "2 hours ago",
  },
  {
    id: "2",
    name: "Employee Onboarding",
    description: "Provisions accounts across Slack, Jira, and Google Workspace.",
    department: "HR",
    owner: {
      id: "2",
      name: "Sarah Chen",
      email: "sarah@wrk.com",
      avatar: "https://github.com/shadcn.png",
    },
    version: "v1.1",
    status: "Build in Progress",
    progress: 65,
    runs: 0,
    success: 0,
    spend: 0,
    updated: "1 day ago",
  },
  {
    id: "3",
    name: "Sales Lead Routing",
    description: "Enriches leads from Typeform and assigns to Account Execs.",
    department: "Sales",
    owner: {
      id: "3",
      name: "Mike Ross",
      email: "mike@wrk.com",
      avatar: "",
    },
    version: "v3.0",
    status: "Awaiting Client Approval",
    runs: 850,
    success: 99.1,
    spend: 210,
    updated: "3 days ago",
  },
  {
    id: "4",
    name: "Legal Document Review",
    description: "First-pass review of NDAs using GPT-4.",
    department: "Legal",
    owner: currentUser,
    version: "v1.0",
    status: "Build in Progress",
    runs: 45,
    success: 82.0,
    spend: 85,
    updated: "5 hours ago",
  },
  {
    id: "5",
    name: "Customer Support Triaging",
    description: "Classifies incoming tickets and suggests responses.",
    department: "Support",
    owner: {
      id: "4",
      name: "Jessica Pearson",
      email: "jessica@wrk.com",
      avatar: "",
    },
    version: "v0.9",
    status: "Intake in Progress",
    runs: 0,
    success: 0,
    spend: 0,
    updated: "1 week ago",
  },
];




