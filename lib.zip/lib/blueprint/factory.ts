// DEPRECATED: use '@/lib/workflows/factory'
export * from "@/lib/workflows/factory";
