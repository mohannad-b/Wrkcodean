// DEPRECATED: use '@/lib/workflows/ai-builder'
export * from "@/lib/workflows/ai-builder";
