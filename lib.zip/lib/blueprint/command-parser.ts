// DEPRECATED: use '@/lib/workflows/command-parser'
export * from "@/lib/workflows/command-parser";
