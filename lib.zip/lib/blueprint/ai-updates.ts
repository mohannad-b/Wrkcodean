// DEPRECATED: use '@/lib/workflows/ai-updates'
export * from "@/lib/workflows/ai-updates";
