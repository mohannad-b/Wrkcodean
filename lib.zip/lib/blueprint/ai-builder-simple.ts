// DEPRECATED: use '@/lib/workflows/ai-builder-simple'
export * from "@/lib/workflows/ai-builder-simple";
