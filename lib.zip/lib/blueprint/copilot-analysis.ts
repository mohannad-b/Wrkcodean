// DEPRECATED: use '@/lib/workflows/copilot-analysis'
export * from "@/lib/workflows/copilot-analysis";
