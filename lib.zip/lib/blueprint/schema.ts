// DEPRECATED: use '@/lib/workflows/schema'
export * from "@/lib/workflows/schema";
